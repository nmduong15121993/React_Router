import React from 'react';

import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

import {Main} from './Component/Main';
import {Main1} from './Component/Main1';
// import {Main2} from './Component/Main2';
// import {Main3} from './Component/Main3';
// import {Main4} from './Component/Main4';

// import {Test} from './Component/Test';
import {Test1} from './Component/Test1';
// import {Test2} from './Component/Test2';

const App = () => {




  return (
    // <Router>
    //   <Main />
    //   <Route path="/test" exact component={Test} />
    //   <Route path="/main1" exact component={Main1} />
    //   <Route path="/main2" exact component={Main2} />
    // </Router>

  //   <Router>
  //     <Switch>
  //       <Route path="/" exact component={Main} />
  //       <Route path="/api">
  //         <Route path="/api/test" exact component={Test} />
  //       </Route>
  //       <Route path="/main1" exact component={Main1} />
  //       <Route path="/main2" exact component={Main2} />
  //     </Switch>
  // </Router>

  // <Router>

  //   <Switch>
  //     <Route path="/" exact component={Main} />

  //     {/* <Route path="api" exact component={Test} >
  //       <Route path="/api/test1" exact component={Test1} />
  //       <Route path="/api/test2" exact component={Test2} />
  //     </Route> */}

  //     <Switch>
  //       <Test />
  //       <Route path="/api/test1" exact component={Test1} />
  //       <Route path="/api/test2" exact component={Test2} />
  //     </Switch>

  //     <Route path="/main1" exact component={Main1} />
  //     <Route path="/main2" exact component={Main2} />
  //     <Route path="/main3" exact component={Main3} />
  //     <Route path="/main4" exact component={Main4} />
  //   </Switch>
  // </Router>

  <Router>
    <Switch>
      {/* <Route path="/" exact component={Main} /> */}
      <Main/>
      <Route path="/api/test1" exact component={Test1} />
      <Route path="/main1" exact component={Main1} />
    </Switch>

  </Router>


  )
}

export default App;
