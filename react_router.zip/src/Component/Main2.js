
import React from 'react'

import {Link} from 'react-router-dom';

const Main2 = () => {
  return (
    <div>
      <h1>Day La Trang Main 2</h1>
      <Link to="/" >Back To Main</Link>
    </div>
  )
}

export {Main2};