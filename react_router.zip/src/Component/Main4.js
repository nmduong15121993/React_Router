import React from 'react'

import {Link} from 'react-router-dom';

const Main4 = () => {
  return (
    <div>
      <h1>Day La Trang Main 4 </h1>
      <Link to="/" >Back To Main</Link>
    </div>
  )
}

export {Main4};