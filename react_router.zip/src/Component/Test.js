import React from 'react'

import {Link} from 'react-router-dom';

const Test = () => {
  return (
    <div>
      <h1>Day La Trang Test</h1>
      <Link to="/" >Back To Main</Link>
    </div>
  )
}

export {Test};
