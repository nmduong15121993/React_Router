import React from 'react'

import {Link} from 'react-router-dom';

const Test2 = () => {
  return (
    <div>
      <h1>Day La Trang Test 2 </h1>
      <Link to="/" >Back To Main</Link>
    </div>
  )
}

export {Test2};
