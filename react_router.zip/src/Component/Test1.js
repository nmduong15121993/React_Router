import React from 'react'

import {Link} from 'react-router-dom';

const Test1 = () => {
  return (
    <div>
      <h1>Day La Trang Test 1 </h1>
      <Link to="/" >Back To Test 1</Link>
    </div>
  )
}

export {Test1};
